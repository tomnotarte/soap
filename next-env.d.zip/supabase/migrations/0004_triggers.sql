-- Generic updated_at maintenance, applied to every user-owned table.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

create trigger soap_entries_set_updated_at
  before update on public.soap_entries
  for each row execute function public.set_updated_at();

create trigger reminder_settings_set_updated_at
  before update on public.reminder_settings
  for each row execute function public.set_updated_at();

-- On signup: create the profile row and default (disabled) reminder settings.
-- SECURITY DEFINER is required here because this runs before the new user's
-- session exists, so it can't rely on the caller's own RLS-checked identity —
-- it runs as the function owner instead, scoped narrowly to exactly this
-- insert, using the new row's own id/email rather than any client input.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, name)
  values (new.id, new.email, new.raw_user_meta_data ->> 'name');

  insert into public.reminder_settings (user_id, enabled)
  values (new.id, false);

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
