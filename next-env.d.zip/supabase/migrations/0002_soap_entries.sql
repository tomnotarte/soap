create table if not exists public.soap_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,

  entry_date date not null,

  scripture_reference text,
  scripture_text text,
  observation text,
  application text,
  prayer text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- A user may have at most one SOAP entry per devotional day. This is the
  -- source of truth for duplicate prevention — never rely on the frontend
  -- alone to enforce it (spec section 48).
  unique (user_id, entry_date)
);

-- Journal list (newest first) and dashboard "recent entries" both filter by
-- user and sort by date, so this composite index covers the hot path.
create index if not exists soap_entries_user_id_entry_date_idx
  on public.soap_entries (user_id, entry_date desc);

alter table public.soap_entries enable row level security;

create policy "Users can view their own SOAP entries"
  on public.soap_entries for select
  using (auth.uid() = user_id);

create policy "Users can insert their own SOAP entries"
  on public.soap_entries for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own SOAP entries"
  on public.soap_entries for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "Users can delete their own SOAP entries"
  on public.soap_entries for delete
  using (auth.uid() = user_id);
