create table if not exists public.reminder_settings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,

  enabled boolean not null default false,
  reminder_time time,
  timezone text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique (user_id)
);

alter table public.reminder_settings enable row level security;

create policy "Users can view their own reminder settings"
  on public.reminder_settings for select
  using (auth.uid() = user_id);

create policy "Users can insert their own reminder settings"
  on public.reminder_settings for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own reminder settings"
  on public.reminder_settings for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "Users can delete their own reminder settings"
  on public.reminder_settings for delete
  using (auth.uid() = user_id);
