-- Profiles table: one row per auth.users row.
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  name text,
  avatar_url text,

  -- Reserved for future monetization (spec section 38). Not enforced or
  -- used anywhere in the MVP; the core SOAP experience stays free and
  -- unrestricted regardless of these values.
  subscription_status text not null default 'free',
  subscription_plan text not null default 'free',
  subscription_expires_at timestamptz,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Users can view their own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can insert their own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);
