import { ButtonLink } from "@/components/ui/Button";
import { SoapStepCard } from "@/components/marketing/SoapStepCard";

const soapSteps = [
  {
    letter: "S" as const,
    word: "Scripture",
    description: "Read and record the passage you're studying.",
  },
  {
    letter: "O" as const,
    word: "Observation",
    description: "Reflect on what the passage is saying.",
  },
  {
    letter: "A" as const,
    word: "Application",
    description: "Consider how God's Word applies to your life.",
  },
  {
    letter: "P" as const,
    word: "Prayer",
    description: "Respond to God through prayer.",
  },
];

const benefits = [
  "Daily devotional journaling",
  "Personal SOAP journal",
  "Daily reminders",
  "Streak tracking",
  "Calendar history",
  "Private and secure entries",
];

export default function Home() {
  return (
    <>
      <header className="mx-auto flex w-full max-w-5xl items-center justify-between px-6 py-6 sm:px-8">
        <span className="font-display text-lg text-ink">SOAP</span>
        <nav>
          <ButtonLink href="/login" variant="secondary" className="px-5 py-2 text-xs">
            Log in
          </ButtonLink>
        </nav>
      </header>

      <main className="flex-1">
        {/* Hero */}
        <section className="mx-auto flex max-w-3xl flex-col items-center px-6 pt-16 pb-20 text-center sm:px-8 sm:pt-24">
          <h1 className="font-display text-6xl leading-none text-ink sm:text-7xl">
            SOAP
          </h1>
          <p className="mt-5 font-display text-2xl text-moss-strong sm:text-3xl">
            Read. Reflect. Apply. Pray.
          </p>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-muted">
            Build a daily habit of spending time in God&rsquo;s Word with the
            simple S.O.A.P. devotional method.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <ButtonLink href="/signup">Start your SOAP</ButtonLink>
            <ButtonLink href="/login" variant="secondary">
              Log in
            </ButtonLink>
          </div>
        </section>

        {/* The SOAP method */}
        <section className="mx-auto max-w-5xl px-6 pb-20 sm:px-8">
          <h2 className="text-center font-display text-3xl text-ink">
            A simple way to slow down in Scripture
          </h2>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {soapSteps.map((step) => (
              <SoapStepCard key={step.letter} {...step} />
            ))}
          </div>
        </section>

        {/* Benefits */}
        <section className="mx-auto max-w-3xl px-6 pb-20 sm:px-8">
          <div className="rounded-2xl border border-border bg-card p-8 sm:p-10">
            <ul className="grid gap-x-8 gap-y-4 sm:grid-cols-2">
              {benefits.map((benefit) => (
                <li key={benefit} className="flex items-start gap-3">
                  <span
                    aria-hidden
                    className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-moss"
                  />
                  <span className="text-ink">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Final CTA */}
        <section className="mx-auto max-w-3xl px-6 pb-24 text-center sm:px-8">
          <h2 className="font-display text-3xl text-ink">
            Start your SOAP journey today.
          </h2>
          <div className="mt-7">
            <ButtonLink href="/signup">Get started</ButtonLink>
          </div>
        </section>
      </main>

      <footer className="mx-auto w-full max-w-5xl px-6 py-8 text-center text-sm text-ink-muted sm:px-8">
        SOAP — a private devotional journal.
      </footer>
    </>
  );
}
