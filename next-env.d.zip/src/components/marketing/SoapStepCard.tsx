type SoapStepCardProps = {
  letter: "S" | "O" | "A" | "P";
  word: string;
  description: string;
};

export function SoapStepCard({ letter, word, description }: SoapStepCardProps) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6 sm:p-7">
      <span className="font-display text-4xl text-moss-strong">{letter}</span>
      <h3 className="mt-3 font-display text-xl text-ink">{word}</h3>
      <p className="mt-2 text-ink-muted leading-relaxed">{description}</p>
    </div>
  );
}
