// Hand-written to match supabase/migrations/*.sql for Phase 1.
// Once you have a live Supabase project, regenerate this with:
//   npx supabase gen types typescript --project-id <your-project-id> > src/types/database.ts

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string | null;
          name: string | null;
          avatar_url: string | null;
          subscription_status: string;
          subscription_plan: string;
          subscription_expires_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email?: string | null;
          name?: string | null;
          avatar_url?: string | null;
          subscription_status?: string;
          subscription_plan?: string;
          subscription_expires_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string | null;
          name?: string | null;
          avatar_url?: string | null;
          subscription_status?: string;
          subscription_plan?: string;
          subscription_expires_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      soap_entries: {
        Row: {
          id: string;
          user_id: string;
          entry_date: string;
          scripture_reference: string | null;
          scripture_text: string | null;
          observation: string | null;
          application: string | null;
          prayer: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          entry_date: string;
          scripture_reference?: string | null;
          scripture_text?: string | null;
          observation?: string | null;
          application?: string | null;
          prayer?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          entry_date?: string;
          scripture_reference?: string | null;
          scripture_text?: string | null;
          observation?: string | null;
          application?: string | null;
          prayer?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      reminder_settings: {
        Row: {
          id: string;
          user_id: string;
          enabled: boolean;
          reminder_time: string | null;
          timezone: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          enabled?: boolean;
          reminder_time?: string | null;
          timezone?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          enabled?: boolean;
          reminder_time?: string | null;
          timezone?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
};
