import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { Database } from "@/types/database";

/**
 * Creates a request-scoped Supabase client for use in Server Components,
 * Route Handlers, and Server Actions. Must be created fresh per request
 * (it closes over the current request's cookies) — do not memoize this one.
 *
 * Only ever uses the public URL + anon key. RLS policies (not this client)
 * are what actually enforce per-user data ownership.
 */
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // Called from a Server Component during render — safe to ignore
            // as long as middleware.ts is also refreshing the session.
          }
        },
      },
    }
  );
}
